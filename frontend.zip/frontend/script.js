document.getElementById("app").innerHTML = `
<h1>Upload de arquivo XLSX para controle de clientes</h1>
<div>
<input type="file" id="fileInput" />
</div>
`;

const fileInput = document.querySelector("#fileInput");
const updateData = document.querySelector("#atualizar-registros")

const uploadFile = file => {
  console.log("Uploading file...");
  const API_ENDPOINT = "http://localhost:8080/clients/upload";
  const request = new XMLHttpRequest();
  const formData = new FormData();
  
  request.open("POST", API_ENDPOINT, true);
  request.setRequestHeader("Access-Control-Allow-Origin", "*");
  request.onreadystatechange = () => {
    if (request.readyState === 4 && request.status === 200) {
      console.log(request.responseText);
    }
  };
  formData.append("file", file);
  request.send(formData);
  document.getElementById("app").innerHTML = `Upload Realizado com sucesso`
};

const getData = async () => {
    const API_ENDPOINT_GET = "http://localhost:8080/clients/findAll";
    const request = new XMLHttpRequest();
    request.open("GET", API_ENDPOINT_GET, true);
    request.setRequestHeader("Access-Control-Allow-Origin", "*");
    const data = await request.send();
   console.log(data)
}

fileInput.addEventListener("change", event => {
  const files = event.target.files;
  uploadFile(files[0]);
});

updateData.addEventListener("click", event => {
    getData()
})